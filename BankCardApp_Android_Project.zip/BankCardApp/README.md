# 📱 بطاقتي | My Cards - Bank Card Manager

تطبيق أندرويد لإدارة البطاقات البنكية بشكل آمن | Secure Android app for managing bank cards

---

## 🚀 طرق بناء الـ APK / Ways to Build APK

### ⭐ الطريقة الأسهل: Android Studio

1. حمّل وثبّت [Android Studio](https://developer.android.com/studio)
2. افتح هذا المجلد: `platforms/android`
3. انتظر حتى يحمّل Gradle (قد يأخذ دقائق)
4. من القائمة: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. ستجد الـ APK في: `app/build/outputs/apk/debug/app-debug.apk`

---

### 🤖 GitHub Actions (مجاناً)

1. ارفع المجلد على GitHub
2. اذهب إلى **Actions** → **Build Android APK** → **Run workflow**
3. حمّل الـ APK من صفحة الـ Artifacts

---

### 💻 Command Line

```bash
# تثبيت المتطلبات / Install requirements
npm install -g cordova

# بناء APK / Build APK
npm install
cordova build android

# الموقع / Location:
# platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📋 المتطلبات / Requirements

| Tool | Version |
|------|---------|
| Java JDK | 17+ |
| Android SDK | API 24-36 |
| Node.js | 18+ |
| Cordova | 13+ |

---

## ✨ مميزات التطبيق / App Features

- 🔐 حماية بـ PIN مكون من 4 أرقام
- 💳 إدارة بطاقات بنكية متعددة
- 👁️ إخفاء/إظهار المعلومات السرية
- 📋 نسخ البيانات بضغطة واحدة
- 📷 QR Code للحساب والـ IBAN
- 🎨 تخصيص ألوان البطاقة
- 🔍 بحث وتصفية البطاقات
- 🌐 يدعم العربية والإنجليزية
- 💾 حفظ البيانات محلياً (offline)

