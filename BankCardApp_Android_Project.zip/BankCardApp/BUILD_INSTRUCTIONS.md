# 📱 بطاقتي - Bank Card Manager APK

## كيفية بناء APK / How to Build APK

### الطريقة الأولى: Android Studio (الأسهل)
1. حمّل [Android Studio](https://developer.android.com/studio)
2. افتح المجلد: `platforms/android`
3. من القائمة: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. ستجد الـ APK في: `app/build/outputs/apk/debug/`

### الطريقة الثانية: Command Line (إذا كان Android SDK مثبتاً)
```bash
cd platforms/android
./gradlew assembleDebug
```
الـ APK سيكون في: `app/build/outputs/apk/debug/app-debug.apk`

### الطريقة الثالثة: Cordova CLI
```bash
npm install -g cordova
cordova build android
```

---

### Method 1: Android Studio (Easiest)
1. Download [Android Studio](https://developer.android.com/studio)
2. Open the folder: `platforms/android`
3. Menu: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. Find APK at: `app/build/outputs/apk/debug/`

### Method 2: Command Line
```bash
cd platforms/android
./gradlew assembleDebug
```

### Requirements
- Android SDK (API 36)
- Java JDK 17+
- Gradle 8+
